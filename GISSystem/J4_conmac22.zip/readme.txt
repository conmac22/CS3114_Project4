J4 Connor Mackert (conmac22)

Compliation: javac *.java
Invoaction: java GIS <database file> <script file> <log file>

Element               Line              File
------------------------------------------------------
Hash table            15                HashTable.java
Hash table element     7                NameEntry.java

PR quadtree            9                PRQuadTree.java
PR quadtree element    7                CoordinateEntry.java

Buffer pool            8                BufferPool.java

GIS record             7                GISRecord.java

Feature name index     7                NameEntry.java

Location index         7                CoordinateEntry.java
