/**
 * Interface for hash function
 */
public interface Hashable<T> 
{
    public int Hash();
}

