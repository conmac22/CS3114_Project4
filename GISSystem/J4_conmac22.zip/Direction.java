/**
 * Represents one of the cardinal directions
 */
public enum Direction {NW, SW, SE, NE, NOQUADRANT};
